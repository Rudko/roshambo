//
//  PlayViewController.swift
//  Roshambo
//
//  Created by Grigory Rudko on 7/6/16.
//  Copyright © 2016 Grigory Rudko. All rights reserved.
//

import UIKit

class PlayViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let rockImage = UIImage(named: "rock") as UIImage?
       
        let rockButton = UIButton(type: UIButtonType.Custom) as UIButton
        rockButton.frame = CGRectMake(70, 150, 75, 65)
        rockButton.setImage(rockImage, forState: .Normal)
        self.view.addSubview(rockButton)
        rockButton.addTarget(self, action: "throwRock", forControlEvents: UIControlEvents.TouchUpInside)
        
    }
    

   
    
    func opponentPlays() -> Int {
      let randomValue = 1 + arc4random() % 3
        return Int(randomValue)
    }
    
    
     @IBAction func throwPaper(sender: AnyObject) {
    }
    @IBAction func throwScissors(sender: AnyObject) {
    }
    
    
    @IBAction func throwRock() {
        var controller: ResultsViewController
        
     controller = self.storyboard?.instantiateViewControllerWithIdentifier("ResultsViewController") as! ResultsViewController
        
    controller.firstValue = self.opponentPlays()
    controller.resultsLabel = UILabel()
        controller.resultsLabel.frame = CGRectMake(100, 250, 300, 60)
        controller.view.addSubview(controller.resultsLabel)
        
    
        if controller.firstValue == 1 {
           controller.resultsLabel.text = "It’s a Tie!"
           print(controller.firstValue)
           print(controller.resultsLabel.text)

             } else if
                controller.firstValue == 2 {
                controller.resultsLabel.text = "Paper beats Rock. Try again..."
                print(controller.firstValue)
                print(controller.resultsLabel.text)
                
        } else if controller.firstValue == 3 {
                  controller.resultsLabel.text = "Rock beats Scissors. You win!"
                  print(controller.firstValue)
                  print(controller.resultsLabel.text)
            
        } else {
        print("...")
        }
        
        
        
        self.presentViewController(controller, animated: true, completion: nil)
    }
    }
  
    
    


    

    

   

   



