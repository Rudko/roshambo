//
//  ResultsViewController.swift
//  Roshambo
//
//  Created by Grigory Rudko on 7/6/16.
//  Copyright © 2016 Grigory Rudko. All rights reserved.
//

import Foundation
import UIKit

class ResultsViewController: UIViewController {
  
    var firstValue: Int? // Btw can I do forced unwrapping here? I do know for sure that it's an Int
    var resultsLabel: UILabel!

    
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        self.resultsLabel = UILabel()
//        resultsLabel.frame = CGRectMake(100, 250, 300, 60)
//        self.view.addSubview(resultsLabel)

    }
    
    
    @IBOutlet weak var resultsImage: UIImageView!
    
     
    
    @IBAction func playAgainButton(sender: AnyObject) {
    }


    

}



