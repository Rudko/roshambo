//
//  ResultsViewController.swift
//  Roshambo
//
//  Created by Grigory Rudko on 7/6/16.
//  Copyright © 2016 Grigory Rudko. All rights reserved.
//

import Foundation
import UIKit

class ResultsViewController: UIViewController {
  
    var firstValue: Int?
    var resultsLabel: UILabel!

    
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.resultsLabel = UILabel()
        resultsLabel.frame = CGRectMake(100, 250, 300, 60)
        resultsLabel.text = "Just testing"
        self.view.addSubview(resultsLabel)
        //self.resultsLabel = resultsLabel
    }
    
    
    @IBOutlet weak var resultsImage: UIImageView!
    
     
    
    @IBAction func playAgainButton(sender: AnyObject) {
    }


    

}



