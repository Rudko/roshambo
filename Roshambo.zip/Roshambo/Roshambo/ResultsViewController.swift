//
//  ResultsViewController.swift
//  Roshambo
//
//  Created by Grigory Rudko on 7/6/16.
//  Copyright © 2016 Grigory Rudko. All rights reserved.
//

import UIKit

class ResultsViewController: UIViewController {
    
    var firstValue: Int?
    var resultsLabel: UILabel!
    var resultsImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func playAgainButton(sender: AnyObject) {
        
    }
}



